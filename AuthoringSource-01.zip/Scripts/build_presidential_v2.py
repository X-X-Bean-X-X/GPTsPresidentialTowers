"""Original Presidential Towers reconstruction, X_Bean_X.
OSM footprint geometry; CVU 140.6m height; photo reconstructed facade/site detail.
All output remains in this project's folder. No downloaded photo becomes a texture.
"""
import bpy,bmesh,math,json,shutil,random
import numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
for d in ['Source','Textures','Renders','Validation','ImportV002/PresidentialTowersCampusV2']:(R/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC'
site=json.loads((R/'References/site-metric.json').read_text())
features={x['id']:x for x in site['features']}
palette=[(159,160,165),(51,59,64),(49,66,76),(77,91,99),(104,114,118),(180,182,181),(27,34,38),(128,129,128),(75,79,79),(50,66,44),(114,100,78),(198,171,102),(59,118,135),(207,203,189),(97,105,110),(141,129,101)]
S=1024;T=256;rng=np.random.default_rng(555)
arrays={k:np.zeros((S,S,4),dtype=np.float32) for k in ['BaseColor','MaskMap','Normal','ControlMask']}
arrays['Normal'][:]=[.5,.5,1,1]
for i,col in enumerate(palette):
 x=i%4*T;y=(3-i//4)*T;arr=arrays['BaseColor'][y:y+T,x:x+T]
 arr[:,:,:3]=np.clip(np.array(col)/255+rng.normal(0,.65,(T,T,1))/255,0,1);arr[:,:,3]=1
 arrays['MaskMap'][y:y+T,x:x+T,0]=.65 if i in [2,3,4,6,12,14,15] else .03
 arrays['MaskMap'][y:y+T,x:x+T,3]=.78 if i in [2,3,4,12,14,15] else .25
 arrays['MaskMap'][y:y+T,x:x+T,2]=1 if i in [3,4,15] else 0
for suffix,arr in arrays.items():
 im=bpy.data.images.new('PT_'+suffix,width=S,height=S,alpha=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'
 im.pixels.foreach_set(arr.reshape(-1));im.filepath_raw=str(R/'Textures'/('PT_'+suffix+'.png'));im.file_format='PNG';im.save()
mat=bpy.data.materials.new('Presidential_Original_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');tx=mat.node_tree.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images['PT_BaseColor'];mat.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
mt=mat.node_tree.nodes.new('ShaderNodeTexImage');mt.image=bpy.data.images['PT_MaskMap'];sep=mat.node_tree.nodes.new('ShaderNodeSeparateColor');mat.node_tree.links.new(mt.outputs['Color'],sep.inputs['Color']);mat.node_tree.links.new(sep.outputs['Red'],bs.inputs['Metallic']);bs.inputs['Roughness'].default_value=.42
class Mesh:
 def __init__(self,name):self.name=name;self.v=[];self.f=[];self.m=[]
 def face(self,pts,m):
  n=len(self.v);self.v.extend(pts);self.f.append(tuple(range(n,n+len(pts))));self.m.append(m)
 def box(self,c,s,m):
  x,y,z=c;a,b,d=[v/2 for v in s];p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def beam(self,a,b,width,depth,m):
  a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
  if x.length<.01:x=z.cross(Vector((0,1,0)))
  x.normalize();y=z.cross(x).normalized();p=[tuple(c+x*i*width/2+y*j*depth/2) for c in [a,b] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def ribbon(self,a,b,width,normal,m):
  a,b=Vector(a),Vector(b);side=(b-a).cross(Vector(normal)).normalized()*width/2
  self.face([tuple(a-side),tuple(b-side),tuple(b+side),tuple(a+side)],m)
 def foliage(self,c,s,m):
  cx,cy,cz=c;rx,ry,rz=s;n=7;rings=[]
  for j in range(1,5):
   theta=math.pi*j/5;rings.append([(cx+rx*math.sin(theta)*math.cos(i*math.tau/n),cy+ry*math.sin(theta)*math.sin(i*math.tau/n),cz+rz*math.cos(theta)) for i in range(n)])
  for i in range(n):
   self.face([(cx,cy,cz+rz),rings[0][i],rings[0][(i+1)%n]],m)
   self.face([(cx,cy,cz-rz),rings[-1][(i+1)%n],rings[-1][i]],m)
  for a,b in zip(rings,rings[1:]):
   for i in range(n):self.face([a[i],b[i],b[(i+1)%n],a[(i+1)%n]],m)
 def prism(self,poly,z0,z1,side,top=None):
  poly=poly[:-1] if poly[0]==poly[-1] else poly
  self.face([(x,y,z0) for x,y in poly][::-1],side);self.face([(x,y,z1) for x,y in poly],side if top is None else top)
  for a,b in zip(poly,poly[1:]+poly[:1]):self.face([(a[0],a[1],z0),(b[0],b[1],z0),(b[0],b[1],z1),(a[0],a[1],z1)],side)
 def finish(self):
  me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.materials.append(mat);me.update();uv=me.uv_layers.new()
  for p,mi in zip(me.polygons,self.m):
   for j,l in enumerate(p.loop_indices):uv.data[l].uv=((mi%4+.15+(j in [1,2])*.7)/4,(3-mi//4+.15+(j>=2)*.7)/4)
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
  ob=bpy.data.objects.new(self.name,me);scene.collection.objects.link(ob);return ob
def poly(id):return features[id]['xy'][:-1]
def simplify(p):
 changed=True
 while changed:
  changed=False
  for i in range(len(p)):
   a,b,c=Vector(p[i-1]),Vector(p[i]),Vector(p[(i+1)%len(p)]);u=b-a;v=c-b
   if u.length<.01 or v.length<.01 or abs(u.normalized().cross(v.normalized()))<.045:
    p=p[:i]+p[i+1:];changed=True;break
 return p
def tower(m,id,lod):
 p=simplify(poly(id));m.prism(p,0,132,0,8);m.prism(p,132,139.3,1,8)
 center=np.mean(np.array(p),axis=0)
 # 46 repeated window levels over a two-level entrance base; mechanical crown completes 49-storey massing.
 for side,(a,b) in enumerate(zip(p,p[1:]+p[:1])):
  a,b=Vector(a),Vector(b);d=b-a;length=d.length;out=Vector((d.y,-d.x)).normalized()
  if out.dot((a+b)/2-Vector(center))<0:out=-out
  def pt(u,z,off=.035):v=a+d*u+out*off;return (v.x,v.y,z)
  cols=max(1,round(length/3.3));rows=46 if lod<2 else 23
  for f in range(rows):
   z0=8+f*124/rows;z1=z0+124/rows
   for k in range(cols):
    u0=(k+.13)/cols;u1=(k+.87)/cols;mi=[2,3,4,14,2,2,15][(f*37+k*19+side*3+int(id[-1]))%7]
    m.face([pt(u0,z0+.42),pt(u1,z0+.42),pt(u1,z1-.43),pt(u0,z1-.43)],mi)
    if lod==0:
     # Recess border, split sash and lower transom, all independent geometry.
     normal=(out.x,out.y,0)
     for u in [u0,u1,(u0+u1)/2]:m.ribbon(pt(u,z0+.42,.065),pt(u,z1-.43,.065),.045,normal,5)
     m.ribbon(pt(u0,z0+.42,.065),pt(u1,z0+.42,.065),.05,normal,5)
     m.ribbon(pt(u0,z1-.43,.065),pt(u1,z1-.43,.065),.05,normal,5)
     m.ribbon(pt(u0,z0+.95,.065),pt(u1,z0+.95,.065),.035,normal,5)
   if lod==0:
    m.beam(pt(0,z0,.016),pt(1,z0,.016),.025,.03,7)
  # Charcoal entrance band with paired windows.
  m.face([pt(0,.1,.06),pt(1,.1,.06),pt(1,8,.06),pt(0,8,.06)],1)
  for k in range(cols):
   for z in [1.2,5.1]:m.face([pt((k+.2)/cols,z,.09),pt((k+.8)/cols,z,.09),pt((k+.8)/cols,z+1.5,.09),pt((k+.2)/cols,z+1.5,.09)],2)
  if length>25:
   for u in [.35,.62]:
    m.face([pt(u-.025,135,.08),pt(u+.025,135,.08),pt(u+.025,137,.08),pt(u-.025,137,.08)],6)
    if lod==0:
     for z in np.arange(135.15,137,.22):m.beam(pt(u-.025,float(z),.10),pt(u+.025,float(z),.10),.04,.08,14)
  m.beam(pt(0,139.25),pt(1,139.25),.22,.32,7)
 # Roof plant is reconstructed, not a surveyed mechanical drawing.
 cx,cy=center;m.box((cx,cy,139.65),(22,10,1.9),7)
 if lod<2:
  for dx in [-8,-3,3,8]:
   m.box((cx+dx,cy,140.1),(2.5,3,1),14)
   for dy in [-3,3]:m.box((cx+dx,cy+dy,139.8),(2,1.5,.6),6)
  for dx in [-14,14]:m.beam((cx+dx,cy,139.3),(cx+dx,cy,140.6),.09,.09,5)
def facade(m,a,b,z0,z1,lod,glass=True):
 a,b=Vector(a),Vector(b);d=b-a;out=Vector((d.y,-d.x)).normalized();n=max(1,round(d.length/3.2))
 def p(u,z,off=.05):v=a+d*u+out*off;return(v.x,v.y,z)
 if glass:
  for i in range(n):
   u0=(i+.04)/n;u1=(i+.96)/n;m.face([p(u0,z0+.3),p(u1,z0+.3),p(u1,z1-.4),p(u0,z1-.4)],2 if i%3 else 3)
   if lod<2:m.beam(p(i/n,z0),p(i/n,z1),.10,.12,5)
  for z in [z0,z0+(z1-z0)*.55,z1]:m.beam(p(0,z),p(1,z),.12,.15,5)
 else:
  for z in np.arange(z0+1.4,z1,3):
   for i in range(n):m.face([p((i+.08)/n,float(z)),p((i+.92)/n,float(z)),p((i+.92)/n,float(z)+1.15),p((i+.08)/n,float(z)+1.15)],6)
  for z in np.arange(z0,z1,3):m.beam(p(0,float(z)),p(1,float(z)),.20,.28,7)
def clip_apron(p):
 # Adapt pavement to the wider Chicago GPT road rights-of-way; preserve building footprints.
 for a,b,c in [(0,1,65.5),(.021,-1,59.3)]:
  out=[]
  for u,v in zip(p,p[1:]+p[:1]):
   du=a*u[0]+b*u[1]-c;dv=a*v[0]+b*v[1]-c
   if du<=0:out.append(u)
   if (du<=0)!=(dv<=0):
    t=du/(du-dv);out.append([u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])])
  p=out
 return p
def pitched_glass(m,a,b,width,z,rise,lod):
 a,b=Vector((*a,z)),Vector((*b,z));d=(b-a).normalized();n=Vector((-d.y,d.x,0))
 for sign in [-1,1]:
  q=a+n*width*sign/2;r=b+n*width*sign/2
  m.face([tuple(q),tuple(r),tuple(b+Vector((0,0,rise))),tuple(a+Vector((0,0,rise)))],2)
  if lod<2:
   for t in np.linspace(0,1,max(2,int((b-a).length/1.4))):
    c=a+(b-a)*float(t);m.beam(c+n*width*sign/2,c+Vector((0,0,rise)),.07,.1,5)
   for t in [.33,.66]:m.beam(a+n*width*sign*(1-t)/2+Vector((0,0,rise*t)),b+n*width*sign*(1-t)/2+Vector((0,0,rise*t)),.06,.08,5)
def tree(m,x,y,z,size=1):
 m.beam((x,y,z),(x+.2,y,z+4.8*size),.22*size,.22*size,10)
 for dx,dy,dz,rad in [(0,0,5.8,2.8),(-1.5,0,4.7,2.1),(1.2,1.1,5.3,2.2),(0,-1.5,5.1,2.0)]:m.foliage((x+dx*size,y+dy*size,z+dz*size),(rad*size,rad*size,rad*1.1*size),9)
def build(lod):
 m=Mesh('PresidentialTowersCampusV2'+(f'_LOD{lod}' if lod else ''))
 # Separate site aprons preserve the Jefferson right-of-way.
 for id in ['1052127891','1052127892']:m.prism(clip_apron(poly(id)),0,.12,7,13)
 # Eastern retail podium with true plan's north recess and two tower-connected lobbies.
 m.prism(poly('150857023'),.12,8.7,1,8)
 # Western garage remains a distinct four-storey volume north of tower 3.
 m.prism(poly('233930076'),.12,12.4,0,8)
 m.prism(poly('541939631'),.12,8,0,13)
 m.prism(poly('1499491247'),.12,7.8,1,8)
 for id in ['148910681','148910682','148910683','148910680']:tower(m,id,lod)
 # Public retail frontage on Clinton, Monroe and Jefferson.
 for a,b in [((108.9,-54.6),(108.9,19)),((14.4,-56.2),(108.9,-54.8)),((12.5,-8),(14.4,-56.2))]:facade(m,a,b,.3,7.7,lod)
 # Long horizontal panel seams distinguish retail cladding from tower concrete.
 if lod<2:
  for z in [4,8.1]:m.beam((14.4,-56.3,z),(108.9,-54.9,z),.08,.12,7)
 # Glass fitness pavilion set back at the Clinton notch.
 m.box((94.5,29.7,4.6),(17.5,20.5,9.0),2)
 facade(m,(103.3,19.4),(103.3,40),.3,9,lod);facade(m,(85.7,40),(103.3,40),.3,9,lod)
 # Two diagonal glazed lobby links, including pitched skylights.
 for a,b in [((53,33),(67,47)),((-64,-40),(-48,-24))]:
  aa=Vector((a[0],a[1],0));bb=Vector((b[0],b[1],0));d=(bb-aa).normalized();n=Vector((-d.y,d.x,0));w=6.2
  for sign in [-1,1]:
   q0=aa+n*w*sign;q1=bb+n*w*sign;facade(m,q0.xy,q1.xy,.5,5,lod)
   m.face([tuple(q0+Vector((0,0,5))),tuple(q1+Vector((0,0,5))),tuple(bb+Vector((0,0,8.5))),tuple(aa+Vector((0,0,8.5)))],2)
  if lod<2:
   for t in np.linspace(0,1,10):
    c=aa+(bb-aa)*float(t)
    for sign in [-1,1]:m.beam(c+n*w*sign+Vector((0,0,5)),c+Vector((0,0,8.5)),.09,.12,5)
 # Bridge over Jefferson, visible in official oblique photo. Clear ground road beneath.
 m.box((0,5.8,7.1),(26,7,3.6),0)
 facade(m,(-13,2.2),(13,2.2),5.5,8.7,lod);facade(m,(13,9.4),(-13,9.4),5.5,8.7,lod)
 # Parking facade, parapet and rooftop stalls.
 gp=poly('233930076')[::-1]
 for a,b in zip(gp,gp[1:]+gp[:1]):
  if (Vector(b)-Vector(a)).length>12:facade(m,a,b,.4,12.2,lod,False)
  m.beam((a[0],a[1],12.8),(b[0],b[1],12.8),.35,1,0)
 if lod<2:
  for y in [3,20,42,58]:
   for x in np.arange(-103,-23,2.65):m.box((float(x),y,12.43),(.09,5,.025),13)
  for x,y in [(-42,42),(-76,20),(-94,42),(-55,3)]:m.box((x,y,13.0),(1.8,4.2,1.15),14);m.box((x,y-.2,13.6),(1.65,2.3,.35),2)
 # Multi-level eastern podium reconstructed from user's 2026-10-21 aerial reference.
 # The large atrium roof, two green-roof pavilions and pool are separate volumes.
 atrium=[(14,-8),(43,-8),(59,-2),(103,14),(103,33),(69,42),(52,32),(51,13),(19,12)]
 m.prism(atrium,8.7,11.5,0,13)
 pitched_glass(m,(43,-5),(99,15),5.4,11.6,2.1,lod)
 pitched_glass(m,(100,16),(101,35),5.2,11.6,2.1,lod)
 pitched_glass(m,(53,31),(67,45),9,8.8,3.3,lod)
 # Raised rectangular gym/amenity volume and the smaller Clinton pavilion.
 big=[(54,-39),(87,-38.4),(87,-8),(54,-8.6)]
 small=[(89,14),(105,14.4),(105,30),(89,27)]
 for pp,height in [(big,15.2),(small,14.3)]:
  m.prism(pp,8.7,height,14,9)
  for a,b in zip(pp,pp[1:]+pp[:1]):
   m.beam((*a,height+.15),(*b,height+.15),.3,.35,5)
   if lod<2:
    for zz in np.arange(9.1,height,.55):m.ribbon((*a,float(zz)),(*b,float(zz)),.045,(b[1]-a[1],a[0]-b[0],0),7)
  if lod==0:
   rr=random.Random(555+int(height*10))
   for i in range(65 if height>15 else 25):
    xx=rr.uniform(min(v[0] for v in pp)+1,max(v[0] for v in pp)-1);yy=rr.uniform(min(v[1] for v in pp)+1,max(v[1] for v in pp)-3)
    m.foliage((xx,yy,height+.15),(.35,.35,.18),9)
 # Pool and narrow surrounding timber deck are on the Clinton edge.
 m.box((97,0,8.85),(19,26,.25),10);m.box((98,0,9.02),(10,20,.12),12)
 for y in [-10.5,10.5]:m.box((98,y,9.13),(11,.45,.22),5)
 for x in [92.5,103.5]:m.box((x,0,9.13),(.45,21,.22),5)
 if lod<2:
  for y in [-8,-4,0,4,8]:
   m.box((89.8,y,9.3),(1.2,2,.18),5);m.box((89.8,y+.6,9.6),(1.2,.5,.7),5)
  for x in [92,96,100]:
   m.box((x,12,9.4),(1.2,1.7,.15),5)
  for y in [4,7]:
   for x in [102.5,103.2]:m.beam((x,y,8.9),(x,y,9.7),.045,.045,5)
 # Southwest rooftop garden: irregular beds, mature trees and paved circulation.
 m.prism([(17,-52),(51,-51.4),(51,-9),(30,-9),(17,-17)],8.7,8.9,13,13)
 beds=[[(20,-47),(28,-47),(31,-42),(26,-36),(19,-38)],[(34,-47),(47,-47),(47,-36),(40,-34),(34,-38)],[(19,-30),(27,-32),(31,-25),(26,-20),(19,-22)],[(34,-29),(48,-30),(48,-19),(42,-15),(35,-18)],[(19,-15),(25,-15),(29,-10),(19,-10)]]
 for bed in beds:
  m.prism(bed,8.9,9.35,5,9)
  if lod<2:
   center=np.mean(np.array(bed),axis=0)
   tree(m,float(center[0]),float(center[1]),9.4,.95)
   for aa in bed:m.foliage((aa[0]+.7,aa[1]+.7,9.8),(1.5,1.5,.7),9)
 if lod<2:
  for x,y in [(30,-44),(31,-36),(31,-20),(43,-12),(22,-34)]:
   m.box((x,y,9.6),(2.3,1.1,.12),10)
   for xx in [x-1.3,x+1.3]:m.box((xx,y,9.3),(.45,1.2,.5),5)
  # East podium south/service terrace and its stair/railing transitions.
  for i in range(14):m.box((49.5,-7+i*.3,8.9+(i+1)*.19),(4,.3,.19),13)
  for x in [47.5,51.5]:m.beam((x,-7,10),(x,-2.8,12.7),.07,.07,5)
  for a,b in [((17,-52),(107,-50.5)),((107,-50.5),(107,13)),((17,-52),(17,-17))]:
   m.beam((*a,10),(*b,10),.09,.09,5)
   d=Vector(b)-Vector(a)
   for t in np.linspace(0,1,max(2,int(d.length/2.5))):
    p=Vector(a)+d*float(t);m.beam((p.x,p.y,8.9),(p.x,p.y,10),.06,.06,5)
  for x in np.arange(18,108,2.5):m.box((float(x),-48,8.93),(.018,6,.02),7)
  for x in [61,69,77,85,99]:
   m.box((x,8,12.2),(2.5,3,1.3),7);m.box((x,8,12.9),(2,2.5,.12),6)
  for x in [62,68,74,80,86]:
   m.box((x,-45,9.55),(2.5,4,1.2),7)
   for yy in [-46,-45,-44]:m.box((x,yy,10.2),(2,.55,.1),6)
 # Ground entrances, awnings, storefront doors and street-facing landscape.
 for x,y in [(59,43),(14,-18),(109,-23),(-51,-30),(-108,-34)]:
  m.box((x,y,3.5),(5,3,.2),1)
  for dx in [-1,1]:m.box((x+dx,y,1.7),(1.6,.12,3.1),2)
 m.box((31,52,.35),(30,18,.45),9)
 if lod<2:
  for x,y in [(20,60),(40,60),(18,42),(48,51)]:tree(m,x,y,.5,.8)
  # Western landscaped terrace beside the tower connection.
  m.prism([(-99,-29),(-72,-29),(-58,-18),(-70,-14),(-103,-19)],8,8.3,5,9)
  for x,y in [(-94,-24),(-86,-22),(-77,-22),(-69,-18),(-93,-30),(-81,-29)]:tree(m,x,y,8.3,1.1)
 if lod==0:
  for x in [56,59,62,65]:m.box((x,47,.65),(.18,.18,1.3),5)
 return m.finish()
objs=[build(i) for i in range(3)]
for i,o in enumerate(objs):o.hide_render=i!=0;o.hide_set(i!=0)
scene.world=bpy.data.worlds.new('Chicago daylight');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.54,.63,.75,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.6
bpy.ops.object.light_add(type='SUN');sun=bpy.context.object;sun.data.energy=2.6;sun.rotation_euler=(.45,-.6,-.55);sun.data.angle=.10
bpy.ops.object.camera_add(location=(330,420,280));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=310;cam.data.clip_end=4000
def aim(p):cam.rotation_euler=(Vector(p)-cam.location).to_track_quat('-Z','Y').to_euler()
aim((0,0,59));scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
try:
 prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
 for dev in prefs.devices:dev.use=dev.type=='OPTIX'
 if any(dev.type=='OPTIX' for dev in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
scene.render.resolution_x=1800;scene.render.resolution_y=1400;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.6;scene.render.image_settings.file_format='PNG'
scene['author']='X_Bean_X';scene['provenance']='OSM footprints; CVU height; official photo and leasing-plan reconstruction. Unsurveyed detail is approximate.'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/PresidentialTowersCampus_v002.blend'))
reports=[];dest=R/'ImportV002/PresidentialTowersCampusV2'
for lod,o in enumerate(objs):
 o.hide_set(False);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 path=dest/(o.name+'.fbx');bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_space_transform=True,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',mesh_smooth_type='FACE',use_tspace=True,bake_anim=False,add_leaf_bones=False)
 pts=np.array([v.co[:] for v in o.data.vertices]);bm=bmesh.new();bm.from_mesh(o.data);deg=sum(f.calc_area()<1e-9 for f in bm.faces);bm.free()
 reports.append({'lod':lod,'file':path.name,'triangles':len(o.data.polygons),'vertices':len(o.data.vertices),'boundsMin':pts.min(0).tolist(),'boundsMax':pts.max(0).tolist(),'degenerateFaces':deg,'finite':bool(np.isfinite(pts).all()),'uv':bool(o.data.uv_layers)})
 for suffix in arrays:shutil.copy2(R/'Textures'/('PT_'+suffix+'.png'),dest/(o.name+'_'+suffix+'.png'))
 o.hide_set(lod!=0)
(R/'Validation/mesh-export.json').write_text(json.dumps({'meshes':reports,'heightSource':'CVU 140.6m','footprintSource':'OSM 2026-10-21','details':'Photo reconstruction, not measured survey'},indent=2))
for name,loc,target,scale in [('campus-north',(330,420,280),(0,0,59),310),('campus-south',(310,-390,250),(0,0,59),310),('podium-detail',(220,-250,190),(55,-10,13),155),('site-top',(0,0,600),(0,0,0),270)]:
 cam.location=loc;cam.data.ortho_scale=scale;aim(target);scene.render.filepath=str(R/'Renders'/(name+'.png'));bpy.ops.render.render(write_still=True)
print('PRESIDENTIAL_BUILD_COMPLETE '+json.dumps(reports),flush=True)
