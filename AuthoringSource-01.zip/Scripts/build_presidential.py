"""Original Presidential Towers reconstruction, X_Bean_X.
OSM footprint geometry; CVU 140.6m height; photo reconstructed facade/site detail.
All output remains in this project's folder. No downloaded photo becomes a texture.
"""
import bpy,bmesh,math,json,shutil,random
import numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
for d in ['Source','Textures','Renders','Validation','ImportV001/PresidentialTowersCampusV1']:(R/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC'
site=json.loads((R/'References/site-metric.json').read_text())
features={x['id']:x for x in site['features']}
palette=[(159,160,165),(51,59,64),(49,66,76),(77,91,99),(104,114,118),(180,182,181),(27,34,38),(128,129,128),(75,79,79),(50,66,44),(114,100,78),(198,171,102),(59,118,135),(207,203,189),(97,105,110),(141,129,101)]
S=1024;T=256;rng=np.random.default_rng(555)
arrays={k:np.zeros((S,S,4),dtype=np.float32) for k in ['BaseColor','MaskMap','Normal','ControlMask']}
arrays['Normal'][:]=[.5,.5,1,1]
for i,col in enumerate(palette):
 x=i%4*T;y=(3-i//4)*T;arr=arrays['BaseColor'][y:y+T,x:x+T]
 arr[:,:,:3]=np.clip(np.array(col)/255+rng.normal(0,.65,(T,T,1))/255,0,1);arr[:,:,3]=1
 arrays['MaskMap'][y:y+T,x:x+T,0]=.65 if i in [2,3,4,6,12,14,15] else .03
 arrays['MaskMap'][y:y+T,x:x+T,3]=.78 if i in [2,3,4,12,14,15] else .25
 arrays['MaskMap'][y:y+T,x:x+T,2]=1 if i in [3,4,15] else 0
for suffix,arr in arrays.items():
 im=bpy.data.images.new('PT_'+suffix,width=S,height=S,alpha=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'
 im.pixels.foreach_set(arr.reshape(-1));im.filepath_raw=str(R/'Textures'/('PT_'+suffix+'.png'));im.file_format='PNG';im.save()
mat=bpy.data.materials.new('Presidential_Original_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');tx=mat.node_tree.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images['PT_BaseColor'];mat.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
mt=mat.node_tree.nodes.new('ShaderNodeTexImage');mt.image=bpy.data.images['PT_MaskMap'];sep=mat.node_tree.nodes.new('ShaderNodeSeparateColor');mat.node_tree.links.new(mt.outputs['Color'],sep.inputs['Color']);mat.node_tree.links.new(sep.outputs['Red'],bs.inputs['Metallic']);bs.inputs['Roughness'].default_value=.42
class Mesh:
 def __init__(self,name):self.name=name;self.v=[];self.f=[];self.m=[]
 def face(self,pts,m):
  n=len(self.v);self.v.extend(pts);self.f.append(tuple(range(n,n+len(pts))));self.m.append(m)
 def box(self,c,s,m):
  x,y,z=c;a,b,d=[v/2 for v in s];p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def beam(self,a,b,width,depth,m):
  a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
  if x.length<.01:x=z.cross(Vector((0,1,0)))
  x.normalize();y=z.cross(x).normalized();p=[tuple(c+x*i*width/2+y*j*depth/2) for c in [a,b] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def ribbon(self,a,b,width,normal,m):
  a,b=Vector(a),Vector(b);side=(b-a).cross(Vector(normal)).normalized()*width/2
  self.face([tuple(a-side),tuple(b-side),tuple(b+side),tuple(a+side)],m)
 def foliage(self,c,s,m):
  cx,cy,cz=c;rx,ry,rz=s;n=7;rings=[]
  for j in range(1,5):
   theta=math.pi*j/5;rings.append([(cx+rx*math.sin(theta)*math.cos(i*math.tau/n),cy+ry*math.sin(theta)*math.sin(i*math.tau/n),cz+rz*math.cos(theta)) for i in range(n)])
  for i in range(n):
   self.face([(cx,cy,cz+rz),rings[0][i],rings[0][(i+1)%n]],m)
   self.face([(cx,cy,cz-rz),rings[-1][(i+1)%n],rings[-1][i]],m)
  for a,b in zip(rings,rings[1:]):
   for i in range(n):self.face([a[i],b[i],b[(i+1)%n],a[(i+1)%n]],m)
 def prism(self,poly,z0,z1,side,top=None):
  poly=poly[:-1] if poly[0]==poly[-1] else poly
  self.face([(x,y,z0) for x,y in poly][::-1],side);self.face([(x,y,z1) for x,y in poly],side if top is None else top)
  for a,b in zip(poly,poly[1:]+poly[:1]):self.face([(a[0],a[1],z0),(b[0],b[1],z0),(b[0],b[1],z1),(a[0],a[1],z1)],side)
 def finish(self):
  me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.materials.append(mat);me.update();uv=me.uv_layers.new()
  for p,mi in zip(me.polygons,self.m):
   for j,l in enumerate(p.loop_indices):uv.data[l].uv=((mi%4+.15+(j in [1,2])*.7)/4,(3-mi//4+.15+(j>=2)*.7)/4)
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
  ob=bpy.data.objects.new(self.name,me);scene.collection.objects.link(ob);return ob
def poly(id):return features[id]['xy'][:-1]
def simplify(p):
 changed=True
 while changed:
  changed=False
  for i in range(len(p)):
   a,b,c=Vector(p[i-1]),Vector(p[i]),Vector(p[(i+1)%len(p)]);u=b-a;v=c-b
   if u.length<.01 or v.length<.01 or abs(u.normalized().cross(v.normalized()))<.045:
    p=p[:i]+p[i+1:];changed=True;break
 return p
def tower(m,id,lod):
 p=simplify(poly(id));m.prism(p,0,132,0,8);m.prism(p,132,139.3,1,8)
 center=np.mean(np.array(p),axis=0)
 # 46 repeated window levels over a two-level entrance base; mechanical crown completes 49-storey massing.
 for side,(a,b) in enumerate(zip(p,p[1:]+p[:1])):
  a,b=Vector(a),Vector(b);d=b-a;length=d.length;out=Vector((d.y,-d.x)).normalized()
  if out.dot((a+b)/2-Vector(center))<0:out=-out
  def pt(u,z,off=.035):v=a+d*u+out*off;return (v.x,v.y,z)
  cols=max(1,round(length/3.3));rows=46 if lod<2 else 23
  for f in range(rows):
   z0=8+f*124/rows;z1=z0+124/rows
   for k in range(cols):
    u0=(k+.13)/cols;u1=(k+.87)/cols;mi=[2,3,4,14,2,2,15][(f*37+k*19+side*3+int(id[-1]))%7]
    m.face([pt(u0,z0+.42),pt(u1,z0+.42),pt(u1,z1-.43),pt(u0,z1-.43)],mi)
    if lod==0:
     # Recess border, split sash and lower transom, all independent geometry.
     normal=(out.x,out.y,0)
     for u in [u0,u1,(u0+u1)/2]:m.ribbon(pt(u,z0+.42,.065),pt(u,z1-.43,.065),.045,normal,5)
     m.ribbon(pt(u0,z0+.42,.065),pt(u1,z0+.42,.065),.05,normal,5)
     m.ribbon(pt(u0,z1-.43,.065),pt(u1,z1-.43,.065),.05,normal,5)
     m.ribbon(pt(u0,z0+.95,.065),pt(u1,z0+.95,.065),.035,normal,5)
   if lod==0:
    m.beam(pt(0,z0,.016),pt(1,z0,.016),.025,.03,7)
  # Charcoal entrance band with paired windows.
  m.face([pt(0,.1,.06),pt(1,.1,.06),pt(1,8,.06),pt(0,8,.06)],1)
  for k in range(cols):
   for z in [1.2,5.1]:m.face([pt((k+.2)/cols,z,.09),pt((k+.8)/cols,z,.09),pt((k+.8)/cols,z+1.5,.09),pt((k+.2)/cols,z+1.5,.09)],2)
  if length>25:
   for u in [.35,.62]:
    m.face([pt(u-.025,135,.08),pt(u+.025,135,.08),pt(u+.025,137,.08),pt(u-.025,137,.08)],6)
    if lod==0:
     for z in np.arange(135.15,137,.22):m.beam(pt(u-.025,float(z),.10),pt(u+.025,float(z),.10),.04,.08,14)
  m.beam(pt(0,139.25),pt(1,139.25),.22,.32,7)
 # Roof plant is reconstructed, not a surveyed mechanical drawing.
 cx,cy=center;m.box((cx,cy,139.65),(22,10,1.9),7)
 if lod<2:
  for dx in [-8,-3,3,8]:
   m.box((cx+dx,cy,140.1),(2.5,3,1),14)
   for dy in [-3,3]:m.box((cx+dx,cy+dy,139.8),(2,1.5,.6),6)
  for dx in [-14,14]:m.beam((cx+dx,cy,139.3),(cx+dx,cy,140.6),.09,.09,5)
def facade(m,a,b,z0,z1,lod,glass=True):
 a,b=Vector(a),Vector(b);d=b-a;out=Vector((d.y,-d.x)).normalized();n=max(1,round(d.length/3.2))
 def p(u,z,off=.05):v=a+d*u+out*off;return(v.x,v.y,z)
 if glass:
  for i in range(n):
   u0=(i+.04)/n;u1=(i+.96)/n;m.face([p(u0,z0+.3),p(u1,z0+.3),p(u1,z1-.4),p(u0,z1-.4)],2 if i%3 else 3)
   if lod<2:m.beam(p(i/n,z0),p(i/n,z1),.10,.12,5)
  for z in [z0,z0+(z1-z0)*.55,z1]:m.beam(p(0,z),p(1,z),.12,.15,5)
 else:
  for z in np.arange(z0+1.4,z1,3):
   for i in range(n):m.face([p((i+.08)/n,float(z)),p((i+.92)/n,float(z)),p((i+.92)/n,float(z)+1.15),p((i+.08)/n,float(z)+1.15)],6)
  for z in np.arange(z0,z1,3):m.beam(p(0,float(z)),p(1,float(z)),.20,.28,7)
def build(lod):
 m=Mesh('PresidentialTowersCampusV1'+(f'_LOD{lod}' if lod else ''))
 # Separate site aprons preserve the Jefferson right-of-way.
 for id in ['1052127891','1052127892']:m.prism(poly(id),0,.12,7,13)
 # Eastern retail podium with true plan's north recess and two tower-connected lobbies.
 m.prism(poly('150857023'),.12,8.7,1,8)
 # Western garage remains a distinct four-storey volume north of tower 3.
 m.prism(poly('233930076'),.12,12.4,0,8)
 m.prism(poly('541939631'),.12,8,0,13)
 m.prism(poly('1499491247'),.12,7.8,1,8)
 for id in ['148910681','148910682','148910683','148910680']:tower(m,id,lod)
 # Public retail frontage on Clinton, Monroe and Jefferson.
 for a,b in [((108.9,-54.6),(108.9,19)),((14.4,-56.2),(108.9,-54.8)),((12.5,-8),(14.4,-56.2))]:facade(m,a,b,.3,7.7,lod)
 # Long horizontal panel seams distinguish retail cladding from tower concrete.
 if lod<2:
  for z in [4,8.1]:m.beam((14.4,-56.3,z),(108.9,-54.9,z),.08,.12,7)
 # Glass fitness pavilion set back at the Clinton notch.
 m.box((94.5,29.7,4.6),(17.5,20.5,9.0),2)
 facade(m,(103.3,19.4),(103.3,40),.3,9,lod);facade(m,(85.7,40),(103.3,40),.3,9,lod)
 # Two diagonal glazed lobby links, including pitched skylights.
 for a,b in [((53,33),(67,47)),((-64,-40),(-48,-24))]:
  aa=Vector((a[0],a[1],0));bb=Vector((b[0],b[1],0));d=(bb-aa).normalized();n=Vector((-d.y,d.x,0));w=6.2
  for sign in [-1,1]:
   q0=aa+n*w*sign;q1=bb+n*w*sign;facade(m,q0.xy,q1.xy,.5,5,lod)
   m.face([tuple(q0+Vector((0,0,5))),tuple(q1+Vector((0,0,5))),tuple(bb+Vector((0,0,8.5))),tuple(aa+Vector((0,0,8.5)))],2)
  if lod<2:
   for t in np.linspace(0,1,10):
    c=aa+(bb-aa)*float(t)
    for sign in [-1,1]:m.beam(c+n*w*sign+Vector((0,0,5)),c+Vector((0,0,8.5)),.09,.12,5)
 # Bridge over Jefferson, visible in official oblique photo. Clear ground road beneath.
 m.box((0,5.8,7.1),(26,7,3.6),0)
 facade(m,(-13,2.2),(13,2.2),5.5,8.7,lod);facade(m,(13,9.4),(-13,9.4),5.5,8.7,lod)
 # Parking facade, parapet and rooftop stalls.
 gp=poly('233930076')[::-1]
 for a,b in zip(gp,gp[1:]+gp[:1]):
  if (Vector(b)-Vector(a)).length>12:facade(m,a,b,.4,12.2,lod,False)
  m.beam((a[0],a[1],12.8),(b[0],b[1],12.8),.35,1,0)
 if lod<2:
  for y in [3,20,42,58]:
   for x in np.arange(-103,-23,2.65):m.box((float(x),y,12.43),(.09,5,.025),13)
  for x,y in [(-42,42),(-76,20),(-94,42),(-55,3)]:m.box((x,y,13.0),(1.8,4.2,1.15),14);m.box((x,y-.2,13.6),(1.65,2.3,.35),2)
 # Roof amenity deck, pool, courtyard paths, planted beds, pergolas.
 m.box((71,-20,8.78),(66,49,.16),13);m.box((89,-22,8.9),(12,24,.15),12)
 for y in [-34,-10]:m.box((89,y,9.05),(13,.5,.3),5)
 for x in [82.5,95.5]:m.box((x,-22,9.05),(.5,24,.3),5)
 m.box((44,-30,9.0),(9,17,.5),9);m.box((67,-39,9.0),(17,4,.5),9)
 if lod<2:
  for x in [54,65,76]:
   m.box((x,-8,9.25),(1.3,2.3,.5),10);m.box((x,-3,9.25),(1.3,2.3,.5),10)
  for x in [38,48]:
   for y in [-9,1]:m.box((x,y,10.25),(.18,.18,3),1)
  for x in np.arange(37,50,1.0):m.box((float(x),-4,11.9),(.16,12,.18),10)
 # Entrance lawn/planted strip and low planters on Madison.
 m.box((31,52,.35),(30,18,.45),9)
 if lod==0:
  for x,y in [(20,60),(40,60),(18,42),(48,51),(-103,-29),(-80,-32)]:
   m.box((x,y,.55),(3,3,1),7);m.box((x,y,1.1),(2.7,2.7,.3),9);m.beam((x,y,1.3),(x,y,4.5),.2,.2,10)
   m.foliage((x,y,4.6),(1.8,1.8,2.3),9)
  # Roof ventilation plant on retail base, grills, service doors, lobby bollards.
  for x in [24,31,40]:
   m.box((x,-47,9.6),(4,5,1.6),7)
   for y in [-48.5,-47,-45.5]:m.box((x,y,10.45),(3.4,.6,.08),6)
  for x in [56,59,62,65]:m.box((x,47,0.65),(.18,.18,1.3),5)
  for x in [70,76,82]:m.box((x,-49.5,2.1),(2.2,.13,3.5),6)
 if lod<2:
  # Roof garden subdivision and outdoor furniture reconstructed from official courtyard photos.
  for x,y,w,d in [(43,-25,7,10),(59,-33,8,5),(68,-18,7,8),(58,-13,5,7),(76,-35,5,5)]:
   m.box((x,y,9.15),(w,d,.7),5);m.box((x,y,9.55),(w-.3,d-.3,.15),9)
   for dx,dy in [(-w/4,-d/4),(w/4,d/4),(0,0)]:m.foliage((x+dx,y+dy,10.1),(1.2,1.2,.8),9)
   m.beam((x,y,9.5),(x+.2,y,13.7),.13,.13,10);m.foliage((x,y,14),(2.4,2.1,2.7),9)
  for y in [-36,-31,-26,-21,-16]:
   m.box((79,y,9.4),(1.1,2,.13),5);m.beam((78.45,y+.5,9.5),(78.45,y+1.3,10.2),.08,.08,1);m.beam((79.55,y+.5,9.5),(79.55,y+1.3,10.2),.08,.08,1);m.box((79,y+1,9.85),(1.1,.16,.8),5)
  for x,y in [(54,-25),(62,-23),(56,-5)]:
   m.box((x,y,9.8),(2.5,1.4,.12),10)
   for dx in [-1,1]:m.box((x+dx,y,9.3),(.12,.9,.9),1)
  # Glass terrace guardrails and paving joints.
  for a,b in [((37,-44),(101,-44)),((101,-44),(101,5)),((37,-44),(37,5))]:
   m.beam((*a,10),(*b,10),.09,.09,5)
   d=Vector(b)-Vector(a)
   for t in np.linspace(0,1,max(2,int(d.length/3))):
    p=Vector(a)+d*float(t);m.beam((p.x,p.y,8.9),(p.x,p.y,10),.055,.055,5)
  for x in np.arange(38,100,2.2):m.box((float(x),-20,8.88),(.014,47,.015),7)
  for y in np.arange(-43,4,2.2):m.box((69,float(y),8.88),(62,.014,.015),7)
 return m.finish()
objs=[build(i) for i in range(3)]
for i,o in enumerate(objs):o.hide_render=i!=0;o.hide_set(i!=0)
scene.world=bpy.data.worlds.new('Chicago daylight');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.54,.63,.75,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.6
bpy.ops.object.light_add(type='SUN');sun=bpy.context.object;sun.data.energy=2.6;sun.rotation_euler=(.45,-.6,-.55);sun.data.angle=.10
bpy.ops.object.camera_add(location=(330,420,280));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=310;cam.data.clip_end=4000
def aim(p):cam.rotation_euler=(Vector(p)-cam.location).to_track_quat('-Z','Y').to_euler()
aim((0,0,59));scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=True
try:
 prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
 for dev in prefs.devices:dev.use=dev.type=='OPTIX'
 if any(dev.type=='OPTIX' for dev in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
scene.render.resolution_x=1800;scene.render.resolution_y=1400;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.6;scene.render.image_settings.file_format='PNG'
scene['author']='X_Bean_X';scene['provenance']='OSM footprints; CVU height; official photo and leasing-plan reconstruction. Unsurveyed detail is approximate.'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/PresidentialTowersCampus_v001.blend'))
reports=[];dest=R/'ImportV001/PresidentialTowersCampusV1'
for lod,o in enumerate(objs):
 o.hide_set(False);bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 path=dest/(o.name+'.fbx');bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_space_transform=True,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',mesh_smooth_type='FACE',use_tspace=True,bake_anim=False,add_leaf_bones=False)
 pts=np.array([v.co[:] for v in o.data.vertices]);bm=bmesh.new();bm.from_mesh(o.data);deg=sum(f.calc_area()<1e-9 for f in bm.faces);bm.free()
 reports.append({'lod':lod,'file':path.name,'triangles':len(o.data.polygons),'vertices':len(o.data.vertices),'boundsMin':pts.min(0).tolist(),'boundsMax':pts.max(0).tolist(),'degenerateFaces':deg,'finite':bool(np.isfinite(pts).all()),'uv':bool(o.data.uv_layers)})
 for suffix in arrays:shutil.copy2(R/'Textures'/('PT_'+suffix+'.png'),dest/(o.name+'_'+suffix+'.png'))
 o.hide_set(lod!=0)
(R/'Validation/mesh-export.json').write_text(json.dumps({'meshes':reports,'heightSource':'CVU 140.6m','footprintSource':'OSM 2026-10-21','details':'Photo reconstruction, not measured survey'},indent=2))
for name,loc,target,scale in [('campus-north',(330,420,280),(0,0,59),310),('campus-south',(310,-390,250),(0,0,59),310),('podium-detail',(220,-250,120),(45,-10,20),180),('site-top',(0,0,600),(0,0,0),270)]:
 cam.location=loc;cam.data.ortho_scale=scale;aim(target);scene.render.filepath=str(R/'Renders'/(name+'.png'));bpy.ops.render.render(write_still=True)
print('PRESIDENTIAL_BUILD_COMPLETE '+json.dumps(reports),flush=True)
