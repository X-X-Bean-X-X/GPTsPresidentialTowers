"""Original Presidential Towers reconstruction, X_Bean_X.
OSM footprint geometry; CVU 140.6m height; photo reconstructed facade/site detail.
All output remains in this project's folder. No downloaded photo becomes a texture.
"""
import bpy,bmesh,math,json,shutil,random
import numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
for d in ['Source','Textures/V005','Renders','Validation','ImportV005/PresidentialTowersCampusV5']:(R/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC'
site=json.loads((R/'References/site-metric.json').read_text())
features={x['id']:x for x in site['features']}
palette=[(159,160,165),(51,59,64),(49,66,76),(77,91,99),(104,114,118),(180,182,181),(27,34,38),(128,129,128),(75,79,79),(50,66,44),(114,100,78),(198,171,102),(59,118,135),(207,203,189),(97,105,110),(141,129,101)]
palette[0]=(173,174,172);palette[1]=(31,37,46);palette[5]=(190,192,190);palette[7]=(109,115,123);palette[8]=(70,78,90)
for i in [2,3,4,14,15]:palette[i]=(29,39,49) if i!=14 else (76,83,88)
palette.extend([(29,39,49)]*8+[(31,37,46),(52,65,75),(168,181,204),(31,37,46)]+[(30,30,30)]*4)
palette[27:32]=[(157,164,171),(103,31,35),(31,53,78),(205,202,190),(39,65,53)]
window_ledger=[]
parking_lines=list(np.arange(-103,-23,2.65))
parking_slots=[(float((a+b)/2),y) for y in [3,20,42,58] for a,b in zip(parking_lines,parking_lines[1:])]
parking_selected=random.Random(5552026).sample(range(len(parking_slots)),round(len(parking_slots)*.25))
parking_inventory=[]
S=1024;H=2048;T=256;rng=np.random.default_rng(555)
arrays={k:np.zeros((H,S,4),dtype=np.float32) for k in ['BaseColor','MaskMap','Normal','ControlMask','Emissive']}
arrays['Normal'][:]=[.5,.5,1,1]
for i,col in enumerate(palette):
 x=i%4*T;y=(7-i//4)*T;arr=arrays['BaseColor'][y:y+T,x:x+T]
 arr[:,:,:3]=np.clip(np.array(col)/255+rng.normal(0,.65,(T,T,1))/255,0,1);arr[:,:,3]=1
 arrays['MaskMap'][y:y+T,x:x+T,0]=.12 if i in [2,3,4,12,15] or 16<=i<=23 else .02
 arrays['MaskMap'][y:y+T,x:x+T,3]=.55 if i in [2,3,4,12,15] or 16<=i<=23 else .3
 arrays['MaskMap'][y:y+T,x:x+T,2]=1 if 17<=i<=23 or i in [25,26] else 0
 arrays['Emissive'][y:y+T,x:x+T,:3]=1 if 17<=i<=23 or i in [25,26] else 0
 arrays['Emissive'][y:y+T,x:x+T,3]=1
for suffix,arr in arrays.items():
 im=bpy.data.images.new('PT_'+suffix,width=S,height=H,alpha=True);im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'
 im.pixels.foreach_set(arr.reshape(-1));im.filepath_raw=str(R/'Textures/V005'/('PT_'+suffix+'.png'));im.file_format='PNG';im.save()
mat=bpy.data.materials.new('Presidential_Original_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');tx=mat.node_tree.nodes.new('ShaderNodeTexImage');tx.image=bpy.data.images['PT_BaseColor'];mat.node_tree.links.new(tx.outputs['Color'],bs.inputs['Base Color'])
mt=mat.node_tree.nodes.new('ShaderNodeTexImage');mt.image=bpy.data.images['PT_MaskMap'];sep=mat.node_tree.nodes.new('ShaderNodeSeparateColor');mat.node_tree.links.new(mt.outputs['Color'],sep.inputs['Color']);mat.node_tree.links.new(sep.outputs['Red'],bs.inputs['Metallic']);bs.inputs['Roughness'].default_value=.42
class Mesh:
 def __init__(self,name):self.name=name;self.v=[];self.f=[];self.m=[]
 def face(self,pts,m,normal=None):
  if normal is not None and (Vector(pts[1])-Vector(pts[0])).cross(Vector(pts[2])-Vector(pts[0])).dot(Vector(normal))<0:pts=list(reversed(pts))
  n=len(self.v);self.v.extend(pts);self.f.append(tuple(range(n,n+len(pts))));self.m.append(m)
 def window(self,pts,key,tower,side,floor,col,lod):
  # Stable spatial clusters, independently seeded for each tower/facade/stage.
  import hashlib
  def noise(x):return int.from_bytes(hashlib.sha256(x.encode()).digest()[:8],'little')/2**64
  mask=0
  for stage in range(3):
   cluster=noise(f'{tower}/{side}/{floor//3}/{col//2}/{stage}/cluster')
   individual=noise(f'{key}/{stage}/individual')
   if .30*cluster+.70*individual < [.46,.50,.43][stage]:mask|=1<<stage
  normal=None
  if str(tower) in features:
   c=np.mean(np.array(features[str(tower)]['xy'][:-1]),axis=0);q=np.mean(np.array(pts),axis=0);normal=(q[0]-c[0],q[1]-c[1],0)
  self.face(pts,16+mask,normal)
  if lod==0:window_ledger.append(dict(id=key,tower=tower,facade=side,floor=floor,column=col,mask=mask,center=np.mean(np.array(pts),axis=0).tolist()))
 def box(self,c,s,m):
  x,y,z=c;a,b,d=[v/2 for v in s];p=[(x+i*a,y+j*b,z+k*d) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def beam(self,a,b,width,depth,m):
  a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
  if x.length<.01:x=z.cross(Vector((0,1,0)))
  x.normalize();y=z.cross(x).normalized();p=[tuple(c+x*i*width/2+y*j*depth/2) for c in [a,b] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],m)
 def ribbon(self,a,b,width,normal,m):
  a,b=Vector(a),Vector(b);side=(b-a).cross(Vector(normal)).normalized()*width/2
  self.face([tuple(a-side),tuple(b-side),tuple(b+side),tuple(a+side)],m,normal)
 def foliage(self,c,s,m):
  cx,cy,cz=c;rx,ry,rz=s;n=7;rings=[]
  for j in range(1,5):
   theta=math.pi*j/5;rings.append([(cx+rx*math.sin(theta)*math.cos(i*math.tau/n),cy+ry*math.sin(theta)*math.sin(i*math.tau/n),cz+rz*math.cos(theta)) for i in range(n)])
  for i in range(n):
   self.face([(cx,cy,cz+rz),rings[0][i],rings[0][(i+1)%n]],m)
   self.face([(cx,cy,cz-rz),rings[-1][(i+1)%n],rings[-1][i]],m)
  for a,b in zip(rings,rings[1:]):
   for i in range(n):self.face([a[i],b[i],b[(i+1)%n],a[(i+1)%n]],m)
 def prism(self,poly,z0,z1,side,top=None):
  poly=poly[:-1] if poly[0]==poly[-1] else poly
  if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1]))<0:poly=list(reversed(poly))
  self.face([(x,y,z0) for x,y in poly][::-1],side);self.face([(x,y,z1) for x,y in poly],side if top is None else top)
  for a,b in zip(poly,poly[1:]+poly[:1]):self.face([(a[0],a[1],z0),(b[0],b[1],z0),(b[0],b[1],z1),(a[0],a[1],z1)],side)
 def finish(self):
  me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.materials.append(mat);me.update();uv=me.uv_layers.new()
  for p,mi in zip(me.polygons,self.m):
   for j,l in enumerate(p.loop_indices):uv.data[l].uv=((mi%4+.15+(j in [1,2])*.7)/4,(7-mi//4+.15+(j>=2)*.7)/8)
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.triangulate(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
  ob=bpy.data.objects.new(self.name,me);scene.collection.objects.link(ob);return ob
def poly(id):return features[id]['xy'][:-1]
def simplify(p):
 changed=True
 while changed:
  changed=False
  for i in range(len(p)):
   a,b,c=Vector(p[i-1]),Vector(p[i]),Vector(p[(i+1)%len(p)]);u=b-a;v=c-b
   if u.length<.01 or v.length<.01 or abs(u.normalized().cross(v.normalized()))<.045:
    p=p[:i]+p[i+1:];changed=True;break
 return p
def tower(m,id,lod):
 p=simplify(poly(id));m.prism(p,0,132,0,8);m.prism(p,132,139.3,1,8)
 center=np.mean(np.array(p),axis=0)
 # 46 repeated window levels over a two-level entrance base; mechanical crown completes 49-storey massing.
 for side,(a,b) in enumerate(zip(p,p[1:]+p[:1])):
  a,b=Vector(a),Vector(b);d=b-a;length=d.length;out=Vector((d.y,-d.x)).normalized()
  if out.dot((a+b)/2-Vector(center))<0:out=-out
  def pt(u,z,off=.18):v=a+d*u+out*off;return (v.x,v.y,z)
  cols=max(1,round(length/3.3));rows=46
  for f in range(rows):
   z0=8+f*124/rows;z1=z0+124/rows
   for k in range(cols):
    u0=(k+.13)/cols;u1=(k+.87)/cols;mi=[2,3,4,14,2,2,15][(f*37+k*19+side*3+int(id[-1]))%7]
    m.window([pt(u0,z0+.42),pt(u1,z0+.42),pt(u1,z1-.43),pt(u0,z1-.43)],f'{id}/{side}/{f}/{k}',id,side,f,k,lod)
    if lod==0:
     # Recess border, split sash and lower transom, all independent geometry.
     normal=(out.x,out.y,0)
     for u in [u0,u1,(u0+u1)/2]:m.ribbon(pt(u,z0+.42,.22),pt(u,z1-.43,.22),.045,normal,5)
     m.ribbon(pt(u0,z0+.42,.22),pt(u1,z0+.42,.22),.05,normal,5)
     m.ribbon(pt(u0,z1-.43,.22),pt(u1,z1-.43,.22),.05,normal,5)
     m.ribbon(pt(u0,z0+.95,.22),pt(u1,z0+.95,.22),.035,normal,5)
   if lod==0:
    m.beam(pt(0,z0,.016),pt(1,z0,.016),.025,.03,7)
  # Charcoal entrance band with paired windows.
  m.face([pt(0,.1,.06),pt(1,.1,.06),pt(1,8,.06),pt(0,8,.06)],1,(out.x,out.y,0))
  for k in range(cols):
   for j,z in enumerate([1.2,5.1]):m.window([pt((k+.2)/cols,z,.20),pt((k+.8)/cols,z,.20),pt((k+.8)/cols,z+1.5,.20),pt((k+.2)/cols,z+1.5,.20)],f'{id}/{side}/base{j}/{k}',id,side,-2+j,k,lod)
  if length>25:
   for u in [.35,.62]:
    m.face([pt(u-.025,135,.08),pt(u+.025,135,.08),pt(u+.025,137,.08),pt(u-.025,137,.08)],6,(out.x,out.y,0))
    if lod==0:
     for z in np.arange(135.15,137,.22):m.beam(pt(u-.025,float(z),.10),pt(u+.025,float(z),.10),.04,.08,14)
  m.beam(pt(0,139.25),pt(1,139.25),.16,.18,26)
 # Roof plant is reconstructed, not a surveyed mechanical drawing.
 cx,cy=center;m.box((cx,cy,139.65),(22,10,1.9),7)
 if lod<2:
  for dx in [-8,-3,3,8]:
   m.box((cx+dx,cy,140.1),(2.5,3,1),14)
   for dy in [-3,3]:m.box((cx+dx,cy+dy,139.8),(2,1.5,.6),6)
  for dx in [-14,14]:m.beam((cx+dx,cy,139.3),(cx+dx,cy,140.6),.09,.09,5)
def facade(m,a,b,z0,z1,lod,glass=True):
 a,b=Vector(a),Vector(b);d=b-a;out=Vector((d.y,-d.x)).normalized();n=max(1,round(d.length/3.2))
 def p(u,z,off=.20):v=a+d*u+out*off;return(v.x,v.y,z)
 if glass:
  for i in range(n):
   u0=(i+.04)/n;u1=(i+.96)/n;m.window([p(u0,z0+.3),p(u1,z0+.3),p(u1,z1-.4),p(u0,z1-.4)],f'retail/{tuple(a)}/{tuple(b)}/{z0}/{i}','retail',str(tuple(a)),int(z0),i,lod)
   if lod<2:m.beam(p(i/n,z0),p(i/n,z1),.10,.12,5)
  for z in [z0,z0+(z1-z0)*.55,z1]:m.beam(p(0,z),p(1,z),.12,.15,5)
 else:
  for z in np.arange(z0+1.4,z1,3):
   for i in range(n):m.face([p((i+.08)/n,float(z)),p((i+.92)/n,float(z)),p((i+.92)/n,float(z)+1.15),p((i+.08)/n,float(z)+1.15)],6)
  for z in np.arange(z0,z1,3):m.beam(p(0,float(z)),p(1,float(z)),.20,.28,7)
def clip_apron(p):
 # Adapt pavement to the wider Chicago GPT road rights-of-way; preserve building footprints.
 for a,b,c in [(0,1,65.5),(.021,-1,59.3)]:
  out=[]
  for u,v in zip(p,p[1:]+p[:1]):
   du=a*u[0]+b*u[1]-c;dv=a*v[0]+b*v[1]-c
   if du<=0:out.append(u)
   if (du<=0)!=(dv<=0):
    t=du/(du-dv);out.append([u[0]+t*(v[0]-u[0]),u[1]+t*(v[1]-u[1])])
  p=out
 return p
def pitched_glass(m,a,b,width,z,rise,lod):
 a,b=Vector((*a,z)),Vector((*b,z));d=(b-a).normalized();n=Vector((-d.y,d.x,0))
 for sign in [-1,1]:
  q=a+n*width*sign/2;r=b+n*width*sign/2
  m.face([tuple(q),tuple(r),tuple(b+Vector((0,0,rise))),tuple(a+Vector((0,0,rise)))],25)
  if lod<2:
   for t in np.linspace(0,1,max(2,int((b-a).length/1.4))):
    c=a+(b-a)*float(t);m.beam(c+n*width*sign/2,c+Vector((0,0,rise)),.07,.1,5)
   for t in [.33,.66]:m.beam(a+n*width*sign*(1-t)/2+Vector((0,0,rise*t)),b+n*width*sign*(1-t)/2+Vector((0,0,rise*t)),.06,.08,5)
def tree(m,x,y,z,size=1):
 m.beam((x,y,z),(x+.2,y,z+4.8*size),.22*size,.22*size,10)
 for dx,dy,dz,rad in [(0,0,5.8,2.8),(-1.5,0,4.7,2.1),(1.2,1.1,5.3,2.2),(0,-1.5,5.1,2.0)]:m.foliage((x+dx*size,y+dy*size,z+dz*size),(rad*size,rad*size,rad*1.1*size),9)
def parked_car(m,x,y,kind,color,reverse,lod):
 # Original low-poly decorative vehicles, aligned inside marked rooftop bays.
 length,width,height={'sedan':(4.55,1.78,1.42),'hatchback':(3.85,1.72,1.5),'SUV':(4.65,1.92,1.78),'van':(4.95,1.95,1.96)}[kind]
 z=12.46
 def p(a,b,c):return(x+a,y+b*reverse,z+c)
 m.box(p(0,0,.58),(width,length,.56),color)
 cabin=length*(.51 if kind=='sedan' else .66)
 m.box(p(0,-.16,.92+(height-1.05)/2),(width*.86,cabin,height-.75),2)
 m.box(p(0,-.16,height),(width*.85,cabin,.10),color)
 for side in [-1,1]:
  m.box(p(side*width*.44,-.16,(height+.83)/2),(.065,.11,height-.83),color)
  for end in [-1,1]:
   m.box(p(side*width*.3,end*(length/2+.012),.70),(width*.24,.035,.18),13 if end==1 else 28)
   if lod<2:
    axle=end*length*.31;radius=.30 if kind in ['SUV','van'] else .27
    center=Vector(p(side*(width/2+.035),axle,radius+.04))
    ring=[center+Vector((0,math.cos(i*math.tau/10)*radius,math.sin(i*math.tau/10)*radius)) for i in range(10)]
    m.face([tuple(v) for v in ring],6,(side,0,0))
    hub=[center+Vector((side*.015,math.cos(i*math.tau/8)*radius*.48,math.sin(i*math.tau/8)*radius*.48)) for i in range(8)]
    m.face([tuple(v) for v in hub],14,(side,0,0))

def build(lod):
 m=Mesh('PresidentialTowersCampusV5'+(f'_LOD{lod}' if lod else ''))
 # Separate site aprons preserve the Jefferson right-of-way.
 for id in ['1052127891','1052127892']:m.prism(clip_apron(poly(id)),0,.12,7,13)
 # Eastern retail podium with true plan's north recess and two tower-connected lobbies.
 m.prism(poly('150857023'),.12,8.7,1,8)
 # Western garage remains a distinct four-storey volume north of tower 3.
 m.prism(poly('233930076'),.12,12.4,0,8)
 m.prism(poly('541939631'),.12,8,0,13)
 m.prism(poly('1499491247'),.12,7.8,1,8)
 for id in ['148910681','148910682','148910683','148910680']:tower(m,id,lod)
 # Public retail frontage on Clinton, Monroe and Jefferson.
 for a,b in [((108.9,-54.6),(108.9,19)),((14.4,-56.2),(108.9,-54.8)),((12.5,-8),(14.4,-56.2))]:facade(m,a,b,.3,7.7,lod)
 # Long horizontal panel seams distinguish retail cladding from tower concrete.
 if lod<2:
  for z in [4,8.1]:m.beam((14.4,-56.3,z),(108.9,-54.9,z),.08,.12,7)
 # Glass fitness pavilion set back at the Clinton notch.
 m.box((94.5,29.7,4.6),(17.5,20.5,9.0),2)
 facade(m,(103.3,19.4),(103.3,40),.3,9,lod);facade(m,(85.7,40),(103.3,40),.3,9,lod)
 # Two diagonal glazed lobby links, including pitched skylights.
 for a,b in [((53,33),(67,47)),((-64,-40),(-48,-24))]:
  aa=Vector((a[0],a[1],0));bb=Vector((b[0],b[1],0));d=(bb-aa).normalized();n=Vector((-d.y,d.x,0));w=6.2
  for sign in [-1,1]:
   q0=aa+n*w*sign;q1=bb+n*w*sign;facade(m,q0.xy,q1.xy,.5,5,lod)
   m.face([tuple(q0+Vector((0,0,5))),tuple(q1+Vector((0,0,5))),tuple(bb+Vector((0,0,8.5))),tuple(aa+Vector((0,0,8.5)))],2)
  if lod<2:
   for t in np.linspace(0,1,10):
    c=aa+(bb-aa)*float(t)
    for sign in [-1,1]:m.beam(c+n*w*sign+Vector((0,0,5)),c+Vector((0,0,8.5)),.09,.12,5)
 # Two enclosed Jefferson crossings reconstructed from the supplied oblique photos.
 # Broad rear atrium crossing and slender front tower-to-garage walkway.
 for y,width in [(5.8,7.0),(25.6,3.4)]:
  m.box((0,y,7.1),(27.0,width,3.6),0)
  facade(m,(-13.5,y-width/2-.01),(13.5,y-width/2-.01),5.5,8.7,lod)
  facade(m,(13.5,y+width/2+.01),(-13.5,y+width/2+.01),5.5,8.7,lod)
  m.beam((-13.5,y-width/2,8.94),(13.5,y-width/2,8.94),.16,.16,5)
  m.beam((-13.5,y+width/2,8.94),(13.5,y+width/2,8.94),.16,.16,5)
  if width>5:
   for x in [-8,0,8]:pitched_glass(m,(x-2.7,y),(x+2.7,y),2.8,9.01,.35,lod)
 # Parking facade, parapet and rooftop stalls.
 gp=poly('233930076')[::-1]
 for a,b in zip(gp,gp[1:]+gp[:1]):
  if (Vector(b)-Vector(a)).length>12:facade(m,a,b,.4,12.2,lod,False)
  m.beam((a[0],a[1],12.8),(b[0],b[1],12.8),.35,1,0)
 if lod<2:
  for y in [3,20,42,58]:
   for x in np.arange(-103,-23,2.65):m.box((float(x),y,12.43),(.09,5,.025),13)
 for i,slot in enumerate(parking_selected):
  x,y=parking_slots[slot];kind=['sedan','hatchback','SUV','sedan','van','SUV'][i%6];color=[27,29,30,28,24,31,27][i%7]
  parked_car(m,x,y,kind,color,1 if i%3 else -1,lod)
  if lod==0:parking_inventory.append(dict(slot=slot,center=[x,y],type=kind,colorTile=color))
 # Multi-level eastern podium reconstructed from user's 2026-10-21 aerial reference.
 # The large atrium roof, two green-roof pavilions and pool are separate volumes.
 atrium=[(14,-8),(43,-8),(59,-2),(103,14),(103,33),(69,42),(52,32),(51,13),(19,12)]
 m.prism(atrium,8.7,11.5,0,13)
 pitched_glass(m,(43,-5),(99,15),5.4,11.6,2.1,lod)
 pitched_glass(m,(100,16),(101,35),5.2,11.6,2.1,lod)
 pitched_glass(m,(53,31),(67,45),9,8.8,3.3,lod)
 # Raised rectangular gym/amenity volume and the smaller Clinton pavilion.
 big=[(54,-39),(87,-38.4),(87,-8),(54,-8.6)]
 small=[(89,14),(105,14.4),(105,30),(89,27)]
 for pp,height in [(big,15.2),(small,14.3)]:
  m.prism(pp,8.7,height,14,9)
  for a,b in zip(pp,pp[1:]+pp[:1]):
   m.beam((*a,height+.15),(*b,height+.15),.3,.35,5)
   if lod<2:
    for zz in np.arange(9.1,height,.55):m.ribbon((*a,float(zz)),(*b,float(zz)),.045,(b[1]-a[1],a[0]-b[0],0),7)
  if lod==0:
   rr=random.Random(555+int(height*10))
   for i in range(65 if height>15 else 25):
    xx=rr.uniform(min(v[0] for v in pp)+1,max(v[0] for v in pp)-1);yy=rr.uniform(min(v[1] for v in pp)+1,max(v[1] for v in pp)-3)
    m.foliage((xx,yy,height+.15),(.35,.35,.18),9)
 # Pool and narrow surrounding timber deck are on the Clinton edge.
 m.box((97,0,8.85),(19,26,.25),10);m.box((98,0,9.02),(10,20,.12),12)
 for y in [-10.5,10.5]:m.box((98,y,9.13),(11,.45,.22),5)
 for x in [92.5,103.5]:m.box((x,0,9.13),(.45,21,.22),5)
 if lod<2:
  for y in [-8,-4,0,4,8]:
   m.box((89.8,y,9.3),(1.2,2,.18),5);m.box((89.8,y+.6,9.6),(1.2,.5,.7),5)
  for x in [92,96,100]:
   m.box((x,12,9.4),(1.2,1.7,.15),5)
  for y in [4,7]:
   for x in [102.5,103.2]:m.beam((x,y,8.9),(x,y,9.7),.045,.045,5)
 # Southwest rooftop garden: irregular beds, mature trees and paved circulation.
 m.prism([(17,-52),(51,-51.4),(51,-9),(30,-9),(17,-17)],8.7,8.9,13,13)
 beds=[[(20,-47),(28,-47),(31,-42),(26,-36),(19,-38)],[(34,-47),(47,-47),(47,-36),(40,-34),(34,-38)],[(19,-30),(27,-32),(31,-25),(26,-20),(19,-22)],[(34,-29),(48,-30),(48,-19),(42,-15),(35,-18)],[(19,-15),(25,-15),(29,-10),(19,-10)]]
 for bed in beds:
  m.prism(bed,8.9,9.35,5,9)
  if lod<2:
   center=np.mean(np.array(bed),axis=0)
   tree(m,float(center[0]),float(center[1]),9.4,.95)
   for aa in bed:m.foliage((aa[0]+.7,aa[1]+.7,9.8),(1.5,1.5,.7),9)
 if lod<2:
  for x,y in [(30,-44),(31,-36),(31,-20),(43,-12),(22,-34)]:
   m.box((x,y,9.6),(2.3,1.1,.12),10)
   for xx in [x-1.3,x+1.3]:m.box((xx,y,9.3),(.45,1.2,.5),5)
  # East podium south/service terrace and its stair/railing transitions.
  for i in range(14):m.box((49.5,-7+i*.3,8.9+(i+1)*.19),(4,.3,.19),13)
  for x in [47.5,51.5]:m.beam((x,-7,10),(x,-2.8,12.7),.07,.07,5)
  for a,b in [((17,-52),(107,-50.5)),((107,-50.5),(107,13)),((17,-52),(17,-17))]:
   m.beam((*a,10),(*b,10),.09,.09,5)
   d=Vector(b)-Vector(a)
   for t in np.linspace(0,1,max(2,int(d.length/2.5))):
    p=Vector(a)+d*float(t);m.beam((p.x,p.y,8.9),(p.x,p.y,10),.06,.06,5)
  for x in np.arange(18,108,2.5):m.box((float(x),-48,8.93),(.018,6,.02),7)
  for x in [61,69,77,85,99]:
   m.box((x,8,12.2),(2.5,3,1.3),7);m.box((x,8,12.9),(2,2.5,.12),6)
  for x in [62,68,74,80,86]:
   m.box((x,-45,9.55),(2.5,4,1.2),7)
   for yy in [-46,-45,-44]:m.box((x,yy,10.2),(2,.55,.1),6)
 # Ground entrances, awnings, storefront doors and street-facing landscape.
 for x,y in [(59,43),(14,-18),(109,-23),(-51,-30),(-108,-34)]:
  m.box((x,y,3.5),(5,3,.2),1)
  for dx in [-1,1]:m.box((x+dx,y,1.7),(1.6,.12,3.1),2)
 m.box((31,52,.35),(30,18,.45),9)
 if lod<2:
  for x,y in [(20,60),(40,60),(18,42),(48,51)]:tree(m,x,y,.5,.8)
  # Western landscaped terrace beside the tower connection.
  m.prism([(-99,-29),(-72,-29),(-58,-18),(-70,-14),(-103,-19)],8,8.3,5,9)
  for x,y in [(-94,-24),(-86,-22),(-77,-22),(-69,-18),(-93,-30),(-81,-29)]:tree(m,x,y,8.3,1.1)
 if lod==0:
  for x in [56,59,62,65]:m.box((x,47,.65),(.18,.18,1.3),5)
 return m.finish()

objs=[build(i) for i in range(3)]
scene['author']='X_Bean_X'
scene['revision']='V005 thumbnail-match and native three-stage lighting'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/PresidentialTowersCampus_v005.blend'))
counts=[sum(bool(w['mask']&(1<<i)) for w in window_ledger) for i in range(3)]
assert len({w['id'] for w in window_ledger})==len(window_ledger)
assert all(.30<=c/len(window_ledger)<=.60 for c in counts)
by={}
for w in window_ledger:
 k=str(w['tower'])+'/'+str(w['facade']);by.setdefault(k,[]).append(w)
report=dict(actualWindows=len(window_ledger),litCounts=counts,fractions=[c/len(window_ledger) for c in counts],stageSeconds=[47,73,91],cycleSeconds=211,windows=window_ledger,facades={k:dict(total=len(ws),lit=[sum(bool(w['mask']&(1<<i)) for w in ws) for i in range(3)]) for k,ws in by.items()},countDefinition='One modeled window aperture including its sash panes; tower main floors, tower base and individual retail frontage apertures. Atrium roof glazing, doors, pool and exterior fixtures are separate.')
(R/'Validation/window-ledger-v005.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['windows','facades']}),flush=True)

(R/"Validation/parking-v005.json").write_text(json.dumps(dict(markedSpaces=len(parking_slots),parkedCars=len(parking_inventory),occupancy=len(parking_inventory)/len(parking_slots),vehicles=parking_inventory),indent=2))
