"""Reuse proven native pipeline with scoped names, paths and no unrelated asset edits."""
from pathlib import Path
R=Path(__file__).resolve().parents[1];O=R.parent/'John Hancock Center/Scripts'
for source,target in [('HWLHancockImport20261020_v2','PTImport20261021'),('HWLHancockPackage20261020_v2','PTPackage20261021'),('HWLHancockRead20261020_v2','PTRead20261021'),('HWLHancockSave20261020_v4','PTSave20261021'),('HWLHancockLoad20261020_v2','PTLoad20261021')]:
 s=(O/(source+'.cs')).read_text()
 s=s.replace('John Hancock Center','Presidential Towers - Asset').replace('JohnHancockCenterXBeanXV2','PresidentialTowersCampusV1').replace('ImportV002','ImportV001').replace('v002','v001').replace('b875c20261020f02','c55520261021f01')
 s=s.replace('Hancock Test - ','PT Recovery - ').replace('Chicago GPT - Hancock Placed ','Chicago GPT - Presidential Towers ').replace('Load verified Hancock test','Load verified Presidential Towers checkpoint')
 s=s.replace('H:/Games/GPT, Chicago AI Project/work/bridge','H:/Games/GPT, Chicago AI Project/ACM - Buildings/WIP/Presidential Towers - Asset/Validation')
 # Save completion and diagnostic receipts also stay inside asset folder.
 s=s.replace('H:\\Games\\GPT, Chicago AI Project\\work\\bridge','H:\\Games\\GPT, Chicago AI Project\\ACM - Buildings\\WIP\\Presidential Towers - Asset\\Validation')
 (R/'Scripts'/(target+'.cs')).write_text(s)
