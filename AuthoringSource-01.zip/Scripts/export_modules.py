import bpy,bmesh,json,shutil,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(R/'Source/PresidentialTowersCampus_v001.blend'))
reports=[]
for lod in range(3):
 src=bpy.data.objects['PresidentialTowersCampusV1'+(f'_LOD{lod}' if lod else '')];me=src.data
 for part,offset in [('East',61.5),('West',-61.5),('Link',0)]:
  verts=[];faces=[];uvs=[]
  for p in me.polygons:
   coords=[me.vertices[i].co.copy() for i in p.vertices]
   link=all(abs(v.x)<=13.2 and 2.0<=v.y<=9.7 and 5.1<=v.z<=9.2 for v in coords)
   chosen=link if part=='Link' else not link and ((sum(v.x for v in coords)>0)==(part=='East'))
   if not chosen:continue
   n=len(verts);verts.extend([(v.x-offset,v.y,v.z) for v in coords]);faces.append(tuple(range(n,n+len(coords))));uvs.append([me.uv_layers.active.data[l].uv.copy() for l in p.loop_indices])
  name='PresidentialTowers'+part+'V1'+(f'_LOD{lod}' if lod else '')
  mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.materials.append(me.materials[0]);mesh.update();uv=mesh.uv_layers.new()
  for p,u in zip(mesh.polygons,uvs):
   for i,l in enumerate(p.loop_indices):uv.data[l].uv=u[i]
  ob=bpy.data.objects.new(name,mesh);bpy.context.scene.collection.objects.link(ob)
  bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
  dest=R/'ImportModules'/('PresidentialTowers'+part+'V1');dest.mkdir(parents=True,exist_ok=True)
  bpy.ops.export_scene.fbx(filepath=str(dest/(name+'.fbx')),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_space_transform=True,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',mesh_smooth_type='FACE',use_tspace=True,bake_anim=False,add_leaf_bones=False)
  for suffix in ['BaseColor','MaskMap','Normal','ControlMask']:shutil.copy2(R/'Textures'/('PT_'+suffix+'.png'),dest/(name+'_'+suffix+'.png'))
  pts=np.array(verts);reports.append({'name':name,'triangles':len(faces),'boundsMin':pts.min(0).tolist(),'boundsMax':pts.max(0).tolist(),'placementOffsetEast':offset})
  bpy.data.objects.remove(ob,do_unlink=True)
(R/'Validation/module-export.json').write_text(json.dumps(reports,indent=2))
print(json.dumps(reports))
